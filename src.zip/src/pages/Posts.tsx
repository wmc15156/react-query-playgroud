import PostList from "../PostList.tsx";

export default function PostsPage() {
  return (
    <div>
      <PostList />
    </div>
  );
}
