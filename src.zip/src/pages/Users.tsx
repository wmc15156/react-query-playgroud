import UserList from "../UserList.tsx";

export default function UsersPage() {
  return (
    <>
      <UserList />
    </>
  );
}
