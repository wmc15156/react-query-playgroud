export interface Post {
  title: string;
  body: string;
  id: string;
}
