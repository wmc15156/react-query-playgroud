export const queryKeys = {
  users: "users",
  user: "user",
  posts: "posts",
  post: "post",
};
